#ifndef MAX_ITEM
#define MAX_ITEM

// ItemType.h StackDriver
const int MAX_ITEMS = 10;
#endif
